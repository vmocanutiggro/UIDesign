﻿interface JQuery {
	autosize(): JQuery;
} 