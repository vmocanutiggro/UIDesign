﻿interface JQuery {
	selectpicker(option?: any, event?: JQueryEventObject): JQuery;
} 