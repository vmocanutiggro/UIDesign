﻿interface JQueryAjaxSettings {
    files?: any;
    iframe?: boolean;
}