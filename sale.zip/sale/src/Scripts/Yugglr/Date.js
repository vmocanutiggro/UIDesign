Date.prototype.toFriendlyString = function () {
    var date = this;
    return date.toLocaleString();
};
//# sourceMappingURL=Date.js.map